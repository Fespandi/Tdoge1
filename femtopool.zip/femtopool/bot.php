<?php



date_default_timezone_set("Asia/Jakarta");
system("clear");
/* START COLOR */
$res="\033[0m";
$hitam="\033[0;30m";
$abu2="\033[1;30m";
$putih="\033[0;37m";
$putih2="\033[1;37m";
$red="\033[0;31m";
$red2="\033[1;31m";
$green="\033[0;32m";
$green2="\033[1;32m";
$yellow="\033[0;33m";
$yellow2="\033[1;33m";
$blue="\033[0;34m";
$blue2="\033[1;34m";
$purple="\033[0;35m";
$purple2="\033[1;35m";
$lblue="\033[0;36m";
$lblue2="\033[1;36m";
/* END COLOR */

$pass = "BELAJAR";
$read = file_get_contents("key.txt");
system('clear');
echo $baner = "$green2
     ______  _______________  _  ______
    / __/ / / / ___/  _/ __ \/ |/ / __ \
   _\ \/ /_/ / (_ // // /_/ /    / /_/ /
  /___/\____/\___/___/\____/_/|_/\____/$putih2 OFFICIAL\n";

echo $green2."\n •SILAHKAN AMBIL PASSWORD DI DALAM VIDEO YT KAKEK.\n";
echo $red2." •(The password is in the video)\n";

if ($pass == 'no'){
      echo $red2."Script Sudah Di Off Kan\n";
      exit;                                                       }else{
if($read == $pass){
      echo $green2." •Proses Upload Password \n";
      sleep(5);
}
elseif($read != $pass){
      echo $putih2." •Jangan di skip videonya. anggap aja nonton film Jav\n\n";
      $save = fopen("key.txt", "w");

echo $putih2." •MASUKAN PASSWORD DI SINI : ".$red2;
$p = trim(fgets(STDIN));


system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • / \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • | \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • \ \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • • - \n";
}
system("clear");
echo $green2." •LOADING";
$ar=0;$is=1;while($ar<$is){
$ar++;
echo " • • • • •   Selesai.\n";
}

if($pass == $p){
        fwrite($save, $p);
        echo $putih2."\n •LOGIN BERHASIL\n";
        fclose($save);
        sleep(2);
        echo " •JANGAN LUPA KOPI DAN ROKOK DI SIAPKAN\n";
        sleep(3);
        }else{
        echo $red2." •LOGIN GAGAL, MASUKIN PASSWORD YG BENER DONG. SILAHKAN COBA LAGI\n";
        exit;
        }
        }
}
sleep(3);
system("clear");
$green2.system("toilet --width 70 -f pagga -F border  'FEMTOPOOL'");
echo $baner1 = "$putih2 =================================================================
 |$green2 #### #  # #### # #### #### ####$putih2 SHATOSHI        SERVER$green2 ONLINE$putih2 |
 |$green2 #    #  # #    # #  # #  # #  #                              $putih2 |
 |$green2 #### #  # # ## # #  # #  # #  #                              $putih2 |
 |$green2    # #  # #  # # #  # #  # #  #                              $putih2 |
 |$green2 #### #### #### # #### #  # ####$putih2 STATUS SCRIPT :$red2 V1           $putih2 |
 =================================================================\n";
echo $putih22." TANGGAL ".$green2.date("d.m.Y ").$putih2."  JAM ".$green2.date("H:i:s");
echo "\n ===============================\033[1;31m404\033[1;32m===============================";
echo $baner2 = "
$putih2 •Creator        :$green2 Kakek Sugiono
$putih2 •Support By     :$green2 Indra Yuda
$putih2 •Group Tele     :$green2 @SugionoShatoshi
$putih2 •Channel YT     :$green2 Sugiono Official
$putih2 •Donation Doge  :$green2 DFvVJc9pbty6Jrx94QuB7Da9LAsz7jnsso
$putih2 =================================================================
$red2 •SCRIPT NOT FOR SALE •SCRIPT GRATIS GUNAKAN DENGAN BIJAK YA CUK
 •SEGALA RESIKO DI TANGGUNG CUCUK YA •KAKEK MAU KABUR DULU\n";
echo $blue2." •••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••\n\n";

include"cfg.php";
$ua = array(
"user-agent: Mozilla/5.0 (Linux; Android 9; Redmi Note 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Mobile Safari/537.36",
"cookie: PHPSESSID=".$PHPSESSID,
"content-type: application/x-www-form-urlencoded; charset=UTF-8");
$login = "https://femtopool.live/getlogin.php";
$data = "address=".$address."&reffid=";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $login);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $ua);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_COOKIEJAR, "cookie.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, "cookie.txt");
$res = curl_exec($ch);
$json = json_decode($res);
$lg = $json->result;
echo $putih2." Login ".$green2.$lg."\n";

while("true"){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://femtopool.live/profile.php");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $ua);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$res = curl_exec($ch);
$a = explode('<h1 class="changetext">',$res);
$a1 = explode('</h1>',$a[1]);
echo $putih2.date("[d-m-Y]").$red2.date("[H:i]").$putih2." Balance Mining ".$green2.$a1[0].$red2." BTC\n";

//MENUNGGU
for ($x=60;$x>-1;$x--){
echo "\r \r";
echo "\r"." 🔴 ".$yellow2."Process Claim ".$red2."$x".$yellow2." Second ";
sleep(1);
}
}
